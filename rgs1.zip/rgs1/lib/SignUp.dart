import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rgs/Login.dart';


class Rgs extends StatefulWidget {
  static TextEditingController Controlleruser = TextEditingController();
  @override
  _RgsState createState() => _RgsState();
}

class _RgsState extends State<Rgs> {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
   // TextEditingController Controlleruser = TextEditingController();
    bool hidepassword = true;
    const color = const Color(0xFF563B5A);

    return Container(
      height: height,
      width: width,

      child: Scaffold(


        backgroundColor: Colors.white,

        body:

        Stack(

          children: <Widget>[
            // Map View

            // Show zoom buttons
            SafeArea(
        child: SingleChildScrollView(

            child: Padding(
                padding: const EdgeInsets.only(left: 10.0,top: 20.0,right: 10.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[

                    Container(

                      decoration: BoxDecoration(color:color,
                         // border: Border.all(color: Colors.blueAccent,borderRadius: 5),
                        borderRadius: BorderRadius.circular(25.0),
                      ),

                      width: width,
                      height: height/3,

//                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      margin: const EdgeInsets.all(2.0),
                      padding: EdgeInsets.fromLTRB(0, 100, 0, 0),
                          child: FittedBox(

                            fit: BoxFit.fitWidth,
                            child:Image(image: AssetImage('images/frame.png')),
                          ),

                    ),
                    SizedBox(height: 50),
                    Text("Signup",style:TextStyle(color: color,fontSize: 28,fontWeight: FontWeight.bold) ,),
                    SizedBox(height: 20),
                    Wrap(
                      spacing: 15.0, // gap between adjacent chips
                      runSpacing: 15.0,
                      children: <Widget>[

                    Container(
                      decoration: BoxDecoration(color:Colors.white,
                         border: Border.all(color: color,width: 1),

                        //borderRadius: BorderRadius.circular(25.0),
                      ),
                      width: width,
                      height: 45,
                      margin: const EdgeInsets.all(2.0),
                      padding: EdgeInsets.fromLTRB(10, 10, 5, 5),

                      child: Stack(
                        children: <Widget>[
                          Row(
                            children: [

                             Container(
                                 width:30,
                                 height: 30,
                                 child: FittedBox(
                              fit :BoxFit.fill,
                               child: Padding(
                                 padding: const EdgeInsets.all(4.0),
                                 child: Image(image:AssetImage('images/vector2.png')),
                               ),
                              )
                             ),
                             Container(
                               margin: EdgeInsets.fromLTRB(20, 0, 0, 0),
                               height: 50,
                               width: width-100,
                               child: TextFormField(

                                 style: TextStyle(fontSize: 16,  color: Colors.black),
                                decoration: const InputDecoration(
                               //   hintStyle: TextStyle(color: Colors.red),
                                  //icon: Icon(Icons.person),
                                 hintText: 'Name',
                                  //labelText: 'Name ',
                                    border: InputBorder.none,
                                    labelStyle: TextStyle(
                                        color:  Colors.grey,fontSize: 18
                                    )



                                ),
                                onSaved: (String? value) {
                                  // This optional block of code can be used to run
                                  // code when the user saves the form.
                                },
                                validator: (String? value) {
                                  return (value != null && value.contains('@')) ? 'Do not use the @ char.' : null;
                                },
                              ),
                             ),


                            ],
                          )

                        ],
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(color:Colors.white,
                        border: Border.all(color: color,width: 1),

                        //borderRadius: BorderRadius.circular(25.0),
                      ),
                      width: width,
                      height: 45,
                      margin: const EdgeInsets.all(2.0),
                      padding: EdgeInsets.fromLTRB(10, 10, 5, 5),


                      child: Stack(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,

                            children: [
                              Container(
                                  width:30,
                                  height: 30,
                                  child: FittedBox(
                                    fit :BoxFit.fill,
                                    child: Padding(
                                      padding: const EdgeInsets.all(4.0),
                                      child: Image(image:AssetImage('images/vector.png')),
                                    ),
                                  )
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(20, 0, 0, 0),
                                height: 50,
                                width: width-100,
                                child: TextFormField(
                                  style: TextStyle(fontSize: 16,  color: Colors.black,
                                      ),
                                  decoration: const InputDecoration(
                                    //icon: Icon(Icons.person),
                                    hintText: 'E-mail ',
                                    //labelText: 'E-mail ',
                                      border: InputBorder.none,
                                      labelStyle: TextStyle(
                                          color:   Colors.grey,fontSize: 18
                                      )


                                  ),
                                  onSaved: (String? value) {
                                    // This optional block of code can be used to run
                                    // code when the user saves the form.
                                  },
                                  validator: (String? value) {
                                    return (value != null && value.contains('@')) ? 'Do not use the @ char.' : null;
                                  },
                                ),
                              ),

                            ],
                          )

                        ],
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(color:Colors.white,
                        border: Border.all(color: color,width: 1),

                        //borderRadius: BorderRadius.circular(25.0),
                      ),
                      width: width,
                      height: 45,
                      margin: const EdgeInsets.all(2.0),
                      padding: EdgeInsets.fromLTRB(10, 10, 5, 5),

                      child: Stack(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,

                            children: [
                              Container(
                                  width:30,
                                  height: 30,
                                  child: FittedBox(
                                    fit :BoxFit.fill,
                                    child: Padding(
                                      padding: const EdgeInsets.all(3.0),
                                      child: Image(image:AssetImage('images/vector2x.png')),
                                    ),
                                  )
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(20, 0, 0, 0),
                                height: 50,
                                width: width-100,
                                child: TextFormField(
                                  style: TextStyle(fontSize: 16,  color: Colors.black),
                                  decoration: const InputDecoration(
                                    //icon: Icon(Icons.person),
                                    hintText: 'Password',
                                    //labelText: 'Password ',
                                      border: InputBorder.none,
                                      labelStyle: TextStyle(
                                          color:   Colors.grey,fontSize: 18
                                      )


                                  ),
                                  onSaved: (String? value) {
                                    // This optional block of code can be used to run
                                    // code when the user saves the form.
                                  },
                                  validator: (String? value) {
                                    return (value != null && value.contains('@')) ? 'Do not use the @ char.' : null;
                                  },
                                ),
                              ),

                            ],
                          )

                        ],
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(color:Colors.white,
                        border: Border.all(color: color,width: 1),

                        //borderRadius: BorderRadius.circular(25.0),
                      ),
                      width: width,
                      height: 45,
                      margin: const EdgeInsets.all(2.0),
                      padding: EdgeInsets.fromLTRB(10, 10, 5, 5),

                      child: Stack(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,

                            children: [
                              Container(
                                  width:30,
                                  height: 30,
                                  child: FittedBox(
                                    fit :BoxFit.fill,
                                    child: Padding(
                                      padding: const EdgeInsets.all(3.0),
                                      child: Image(image:AssetImage('images/vector2x.png')),
                                    ),
                                  )
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(20, 0, 0, 0),
                                height: 50,
                                width: width-100,
                                child: TextFormField(
                                  style: TextStyle(fontSize: 16,  color: Colors.black),
                                  decoration: const InputDecoration(

                                    //icon: Icon(Icons.person),
                                    hintText: 'Confirm Password',
                                    //labelText: 'Confirm Password ',
                                      border: InputBorder.none,
                                      labelStyle: TextStyle(
                                          color:   Colors.grey,fontSize: 18
                                      )

                                  ),
                                  onSaved: (String? value) {
                                    // This optional block of code can be used to run
                                    // code when the user saves the form.
                                  },
                                  validator: (String? value) {
                                    return (value != null && value.contains('@')) ? 'Do not use the @ char.' : null;
                                  },
                                ),
                              ),

                            ],
                          )

                        ],
                      ),
                    ),
                    SizedBox(height: 0,),
                    GestureDetector(
                      onTap: (){
                        Navigator.push(

                          context,
                          MaterialPageRoute(builder: (context) =>  Login()),
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(color:color,
                          border: Border.all(color: color,width: 1),

                          //borderRadius: BorderRadius.circular(25.0),
                        ),
                        width: width,
                        height: 45,
                        margin: const EdgeInsets.all(2.0),
                        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),

                        child: Stack(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,

                              children: [
                                Container(
                                    margin: const EdgeInsets.all(10.0),
                                    color: color,

                                    child: FittedBox(
                                      fit :BoxFit.fill,

                                      child: Text("Sign up",style: TextStyle(fontSize: 25,color: Colors.white,fontWeight: FontWeight.w700),),
                                    )
                                ),
                                Expanded(child: SizedBox( )),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5.0),
                                  clipBehavior: Clip.hardEdge,


                                  child: Material(
                                    color: Colors.white, // button color
                                    child: InkWell(
                                      splashColor: Colors.blue, // inkwell color
                                      child: SizedBox(
                                        width: 50,
                                        height: 40,
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: GestureDetector(
                                              onTap: (){
                                                Navigator.push(

                                                  context,
                                                  MaterialPageRoute(builder: (context) =>  Login()),
                                                );
                                              },
                                              child: Image(image:AssetImage('images/forward.png'))),
                                        ),
                                        // Icon(Icons.keyboard_arrow_right),
                                      ),
                                      onTap: () {

                                        //  mapController.animateCamera(
                                        //  CameraUpdate.zoomIn(),
                                      },
                                    ),
                                  ),
                                ),
                                SizedBox(width:5),
                              ],
                            ),


                          ],
                        ),
                      ),
                    ),
                    ],
                    ),

                  ],

                ),
              ),
            ),

            ),
          ],
        ),

      ),

      // Show the place input fields & button for
    ); // showing the route
  }
}
