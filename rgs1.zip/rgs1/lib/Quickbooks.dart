import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'Login.dart';

class QuickbookPage extends StatefulWidget {

  @override
  _QuickbookPageState createState() => _QuickbookPageState();
}

class _QuickbookPageState extends State<QuickbookPage> {
  @override
  Widget build(BuildContext context) {
    const color = const Color(0xFF563B5A);
    return Scaffold(
        appBar: AppBar(
          backgroundColor: color,
          title: Text("Quick Book  ",style:TextStyle(color: Colors.white,fontSize: 24) ,),
          centerTitle: true,
          actions: [
            IconButton(
                icon: ImageIcon(
                  AssetImage('images/Logout 1@2x.png'),
                ),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                  //code to execute when this button is pressed
                }
            ),
          ],
        ),
        body:  WebView(
          initialUrl: 'https://c1.qbo.intuit.com/qbo1/login?&useNeo=true',
          javascriptMode: JavascriptMode.unrestricted,
        )
    );
  }
}
