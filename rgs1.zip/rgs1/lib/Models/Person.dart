class Person {
  final int id;
  final String name;
  final String email;
  final String phone;

  const Person({
    this.id = 0,
    this.name = '',
    this.email = '',
    this.phone = '',
  });


}