import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'Login.dart';

class BookingMeetingPage extends StatefulWidget {

  @override
  _BookingMeetingPageState createState() => _BookingMeetingPageState();
}

class _BookingMeetingPageState extends State<BookingMeetingPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //Fluttertoast.showToast(msg: "BookingMeetingPage");
  }
  @override
  Widget build(BuildContext context) {
    const color = const Color(0xFF563B5A);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: color,
        title: Text("Booking Meeting ",style:TextStyle(color: Colors.white,fontSize: 24) ,),
        centerTitle: true,
        actions: [
          IconButton(
              icon: ImageIcon(
                AssetImage('images/Logout 1@2x.png'),
              ),
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                //code to execute when this button is pressed
              }
          ),
        ],
      ),
      body:  WebView(
        initialUrl: 'https://calendly.com/rgsbooknow/client?month=2021-11',
        javascriptMode: JavascriptMode.unrestricted,
      )
    );
  }
}
