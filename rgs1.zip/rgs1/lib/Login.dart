import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rgs/ForgotPassword.dart';
import 'package:rgs/Profilescreen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'BottomBar.dart';
import 'Home.dart';

class Login extends StatefulWidget {
  static TextEditingController Controlleruser = TextEditingController();
  @override
  _loginState createState() => _loginState();
}

class _loginState extends State<Login> {
  late bool loginstatus;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getPrefance();
  }
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    // TextEditingController Controlleruser = TextEditingController();
    bool hidepassword = true;
    const color = const Color(0xFF563B5A);

    return Container(
      height: height,
      width: width,

      child: Scaffold(


        backgroundColor: Colors.white,

        body:

        SingleChildScrollView(
          child: Stack(

            children: <Widget>[
              // Map View

              // Show zoom buttons
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.only(left: 10.0,top: 20.0,right: 10.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[

                      Container(

                        decoration: BoxDecoration(color:color,
                          // border: Border.all(color: Colors.blueAccent,borderRadius: 5),
                          borderRadius: BorderRadius.circular(25.0),
                        ),

                        width: width,
                        height: 300,

//                      clipBehavior: Clip.antiAliasWithSaveLayer,
                        margin: const EdgeInsets.all(2.0),
                        padding: EdgeInsets.fromLTRB(0, 100, 0, 0),
                        child: FittedBox(

                          fit: BoxFit.fitWidth,
                          child:Image(image: AssetImage('images/frame.png')),
                        ),

                      ),
                      SizedBox(height: 50),
                      Text("Login",style:TextStyle(color: color,fontSize: 30,fontWeight: FontWeight.bold) ,),
                      SizedBox(height: 20),
                      Wrap(
                        spacing: 5.0, // gap between adjacent chips
                        runSpacing: 25.0,
                        children: <Widget>[


                          Container(
                            decoration: BoxDecoration(color:Colors.white,
                              border: Border.all(color: color,width: 0.5),

                              //borderRadius: BorderRadius.circular(25.0),
                            ),
                            width: width,
                            height: 45,
                            margin: const EdgeInsets.all(2.0),
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 5),


                            child: Stack(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,

                                  children: [
                                    Container(
                                        width:30,
                                        height: 30,
                                        child: FittedBox(
                                          fit :BoxFit.fill,
                                          child: Padding(
                                            padding: const EdgeInsets.all(3.0),
                                            child: Image(image:AssetImage('images/vector.png')),
                                          ),
                                        )
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(20, 0, 0, 0),
                                      height: 50,
                                      width: width-100,
                                      child: TextFormField(
                                        style: TextStyle(fontSize: 16,  color: Colors.black),
                                        decoration: const InputDecoration(
                                            //labelText: 'E-mail Id',

                                          //icon: Icon(Icons.person),
                                          hintText: 'E-mail Id',
                                            border: InputBorder.none,
                                            labelStyle: TextStyle(
                                                color:   Colors.grey
                                            )


                                        ),
                                        onSaved: (String? value) {
                                          // This optional block of code can be used to run
                                          // code when the user saves the form.
                                        },
                                        validator: (String? value) {
                                          return (value != null && value.contains('@')) ? 'Do not use the @ char.' : null;
                                        },
                                      ),
                                    ),

                                  ],
                                )

                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(color:Colors.white,
                              border: Border.all(color: color,width: 0.5),

                              //borderRadius: BorderRadius.circular(25.0),
                            ),
                            width: width,
                            height: 45,
                            margin: const EdgeInsets.all(2.0),
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 5),

                            child: Stack(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,

                                  children: [
                                    Container(
                                        width:30,
                                        height: 30,
                                        child: FittedBox(
                                          fit :BoxFit.fill,
                                          child: Padding(
                                            padding: const EdgeInsets.all(3.0),
                                            child: Image(image:AssetImage('images/vector2x.png')),
                                          ),
                                        )
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(20, 0, 0, 0),
                                      height: 50,
                                      width: width-100,
                                      child: TextFormField(
                                        style: TextStyle(fontSize: 16,  color: Colors.black),
                                        decoration: const InputDecoration(
                                            border: InputBorder.none,
                                          //icon: Icon(Icons.person),
                                         hintText: 'Password',
                                          //labelText: 'Password ',
                                          labelStyle: TextStyle(
                                              color:   Colors.grey
                                          )


                                        ),
                                        onSaved: (String? value) {
                                          // This optional block of code can be used to run
                                          // code when the user saves the form.
                                        },
                                        validator: (String? value) {
                                          return (value != null && value.contains('@')) ? 'Do not use the @ char.' : null;
                                        },
                                      ),
                                    ),

                                  ],
                                )

                              ],
                            ),
                          ),

                        ],
                      ),
                      SizedBox(height: 5,),

                      Container(height: 60,
                          margin: const EdgeInsets.all(2.0),
                          alignment: Alignment.topLeft,

                          child:GestureDetector(
                            onTap: (){
                              Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPassword()));
                            },
                            child: Text("Forgot Password",style: TextStyle(fontSize: 17,color: color),
                            ),
                          )),
                      GestureDetector(
                        onTap: (){
                          var bottom =2;
                          Timer(
                            Duration(seconds: 1),
                                () => Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => BottomBar(bottom: bottom,),
                              ),
                            ),
                          );

                        },
                        child: Container(
                          decoration: BoxDecoration(color:color,
                            border: Border.all(color: color,width: 0.5),

                            borderRadius: BorderRadius.circular(5.0),
                          ),

                          width: width,
                          height: 45,
                          margin: const EdgeInsets.all(2.0),
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 0),

                          child: Stack(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,

                                children: [
                                  Container(
                                      margin: const EdgeInsets.all(10.0),



                                      child: FittedBox(
                                        fit :BoxFit.fill,

                                        child: Text("Login ",style: TextStyle(fontSize: 20,color: Colors.white, fontWeight: FontWeight.w700),),
                                      )
                                  ),
                                  Expanded(child: SizedBox( )),
                                  GestureDetector(
                                    onTap: (){
                                      // Navigator.push(
                                      //
                                      //   context,
                                      //   MaterialPageRoute(builder: (context) =>  Home()),
                                      // );

                                    },

                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(5.0),
                                      clipBehavior: Clip.hardEdge,

                                      child: Material(
                                        color: Colors.white, // button color
                                        child: InkWell(
                                          splashColor: Colors.blue, // inkwell color
                                          child: SizedBox(
                                            width: 50,
                                            height: 40,
                                            child: Padding(
                                              padding: const EdgeInsets.all(4.0),
                                              child: GestureDetector(
                                                  onTap: (){
                                                    // Navigator.push(
                                                    //
                                                    //   context,
                                                    //   MaterialPageRoute(builder: (context) =>  Home()),
                                                    // );
                                                    var bottom =2;
                                                    Timer(
                                                      Duration(seconds: 1),
                                                          () => Navigator.pushReplacement(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) => BottomBar(bottom: bottom,),
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                  child: Image(image:AssetImage('images/forward.png'))),
                                            ),
                                            // Icon(Icons.keyboard_arrow_right),
                                          ),
                                          onTap: () {

                                            //  mapController.animateCamera(
                                            //  CameraUpdate.zoomIn(),
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(width:5),
                                ],
                              ),


                            ],
                          ),
                        ),
                      ),
                    ],

                  ),
                ),
              ),
            ],
          ),
        ),
      ),

      // Show the place input fields & button for
    ); // showing the route
  }
  getPrefance() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      loginstatus = sharedPreferences.getBool('loggedIn')!;
      var index =0;
      Timer(
          Duration(seconds: 3),
              () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                  loginstatus == true ? BottomBar(bottom: index,) : Home()
                //logIN==true?BottomBar() :LoginScreen()
              )));
    });
  }
}