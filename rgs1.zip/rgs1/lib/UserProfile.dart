
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rgs/Login.dart';
import 'package:rgs/Profilescreen.dart';

class UserProfileData extends StatefulWidget {
  const UserProfileData({Key? key}) : super(key: key);

  @override
  _UserProfileDataState createState() => _UserProfileDataState();
}

class _UserProfileDataState extends State<UserProfileData> {
  static const color = const Color(0xFF563B5A);
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(

      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              //color: color,
              height: 270,
              child: Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  Positioned(
                      top: 0,
                      child: Container(
                        width: size.width*0.999,
                        decoration: BoxDecoration(color:color,
                          borderRadius: BorderRadius.only(

                            // topRight: Radius.circular(40.0),
                              bottomRight: Radius.circular(25.0),
                              //topLeft: Radius.circular(40.0),
                              bottomLeft: Radius.circular(25.0)),
                        ),
                        height: 200,
                      )),
                  Positioned(
                      top: 50,
                      child: Container(
                        width: size.width * 0.9,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: (){
                                Navigator.pop(context);

                              },
                              child: Container(
                                child: Icon(

                                  Icons.arrow_back,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            Container(
                              child: Text(
                                "User profile",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 18,fontWeight: FontWeight.w700),
                              ),
                            ),
                            GestureDetector(
                              onTap: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));

                              },
                              child: Container(
                                height: 25,
                                child: Image.asset('images/Logout 1@2x.png')
                              ),
                            )
                          ],
                        ),
                      )),
                  Positioned(
                    top: 135,
                    width: size.width * 0.55,

                    child: new Column(
                      children: <Widget>[
                        new Stack(fit: StackFit.loose, children: <Widget>[
                          new Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              new Container(
                                width: 120.0,
                                height: 120.0,
                                decoration: BoxDecoration(
                                  // color: BackColorCard,
                                  color: Colors.white.withOpacity(.5),
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.grey
                                            .withOpacity(.1),
                                        blurRadius: 4,
                                        spreadRadius: 3)
                                  ],
                                  border: Border.all(
                                    width: 1.5,
                                    color: Colors.grey.withOpacity(.5),
                                  ),
                                  borderRadius: BorderRadius.circular(60.0),
                                ),
                                padding: EdgeInsets.all(5),
                                child: Container(
                                    width: 105.0,
                                    height: 105.0,
                                    decoration: new BoxDecoration(
                                      // shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                            color: Colors.grey.shade200
                                                .withOpacity(.1),
                                            blurRadius: 2,
                                            spreadRadius: 1)
                                      ],
                                      border: Border.all(
                                        width: 1.5,
                                        color: Colors.grey.withOpacity(.5),
                                      ),
                                      borderRadius: BorderRadius.circular(50.0),
                                      image: new DecorationImage(
                                        image: AssetImage(
                                            "images/user.png"),
                                        fit: BoxFit.fill,
                                      ),
                                    )),
                              ),
                            ],
                          ),
                          Padding(
                              padding: EdgeInsets.only(top: 60.0, left: 130.0),
                              child: Container(
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  // color: BackColorCard,
                                  color: Colors.amber.withOpacity(.5),
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.white
                                            .withOpacity(.1),
                                        blurRadius: 4,
                                        spreadRadius: 3)
                                  ],
                                  border: Border.all(
                                    width: 1.5,
                                    color: Colors.white.withOpacity(.5),
                                  ),
                                  borderRadius: BorderRadius.circular(60.0),
                                ),
                                child: new Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    GestureDetector(
                                      child: new CircleAvatar(
                                        backgroundColor: Colors.white,
                                        radius: 16.0,
                                        child: new Image.asset('images/camera.png',scale: 2,
                                        ),
                                      ),
                                      onTap: () {
                                        //selectProfileimage();
                                      },
                                    )
                                  ],
                                ),
                              )),
                        ])
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Text('Rajendra Kumar',
              style: TextStyle(color: color,fontWeight: FontWeight.w700,fontSize: 18),),
            SizedBox(height: 40,),
            Card(
              elevation: 5,
              child: Container(
                padding: EdgeInsets.all(10),
                margin: EdgeInsets.all(5),
                child: Column(
                  children: [
                    Row(
                      children: [
                       Image.asset('images/contactmail.png',height: 25,),
                        SizedBox(width: 15,),

                        Text('hello@rgsaccounts.ac.uk',style: TextStyle(color: Colors.grey),),
                      ],
                    ),
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        Image.asset('images/contactcall.png',height: 25,),
                        SizedBox(width: 15,),

                        Text('hello@rgsaccounts.ac.uk',style: TextStyle(color: Colors.grey)),
                      ],
                    ),
                  ],
                ),
              ),
            ),




            SizedBox(height: 40,),
            Container(
              margin: EdgeInsets.symmetric(vertical: 10),
              width: size.width * 0.98,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(1),
                // ignore: deprecated_member_use
                child: FlatButton(
                  padding: EdgeInsets.symmetric(
                      vertical: 19, horizontal: 20),
                  color: color,
                  onPressed: () {
                    // if (formkey.currentState.validate()) {
                    //   var urname = usernameController.text;
                    //   var pass = passController.text;
                    //   SendLoginData(urname, pass);
                    // }
                    Navigator.push(

                      context,
                      MaterialPageRoute(builder: (context) =>  ProfileScreen()),
                    );
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        " Edit Profile ",
                        style:
                        TextStyle(color: Colors.white, fontSize: 16,fontWeight: FontWeight.w700),
                      ),

                    ],
                  ),
                ),
              ),
            ),



          ],
        ),
      ),
    );
  }
}
