
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'Login.dart';

class AboutusScreen extends StatefulWidget {
  const AboutusScreen({Key? key}) : super(key: key);

  @override
  _AboutusScreenState createState() => _AboutusScreenState();
}

class _AboutusScreenState extends State<AboutusScreen> {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    // TextEditingController Controlleruser = TextEditingController();
    bool hidepassword = true;
    const color = const Color(0xFF563B5A);
    const color2 = const Color(0xFF162037);


    // startTimer();
    return Container(
      height: height,
      width: width,

      child: Scaffold(


        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: color,
          title: Text("About Us ",style:TextStyle(color: Colors.white,fontSize: 24) ,),
          centerTitle: true,
          actions: [
            IconButton(
                icon: ImageIcon(
                  AssetImage('images/Logout 1@2x.png'),
                ),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                  //code to execute when this button is pressed
                }
            ),
          ],
        ),
        body:

        Stack(

            children: <Widget>[
              // Map View

              // Show zoom buttons
              SafeArea(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 10.0,top: 20.0,right: 10.0),
                    child:
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        //   Text("| Income Tax                ",style:TextStyle(color: color,fontSize: 32,fontWeight: FontWeight.bold) ,),
                        Text("| About  RGS ",
                          style:TextStyle(color: color,fontSize: 22,fontWeight: FontWeight.bold) ,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image(height: 200, width: 280, image: AssetImage('images/4860636@2x.png'),),
                          ],
                        ),
                        Text('National Insurance',
                          style: TextStyle(color: Colors.grey,fontSize: 22,fontWeight: FontWeight.w700),),
                        SizedBox(height: 10,),
                        Text('National Insurance Nationalvg Insurance National InsuranceNational National InsuranceNational InsuranceInsurance National Insurance National InsuranceNational Insurance',
                          style: TextStyle(color: Colors.grey,fontSize: 14,fontWeight: FontWeight.w400),),


                      ],

                    ),
                  ),
                ),
              ),
            ]
        ),
        bottomNavigationBar: bottomNavigationBar,
      ),

      // Show the place input fields & button for
    );
  }
  Widget get bottomNavigationBar {
    return
      Container(
        decoration: BoxDecoration(color:Colors.red,
          border: Border.all(width: 0.5),

          borderRadius: BorderRadius.circular(200.0),
        ),
        margin: const EdgeInsets.all(10.0),
        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
        child:
        ClipRRect(

          clipBehavior: Clip.antiAliasWithSaveLayer,

          borderRadius: const BorderRadius.only(
            topRight: Radius.circular(200),
            topLeft: Radius.circular(200),
            bottomLeft: Radius.circular(200),
            bottomRight: Radius.circular(200),

          ),
          child: BottomNavigationBar(
            iconSize: 35,
            items: const [
              BottomNavigationBarItem(

                icon: ImageIcon(

                  AssetImage('images/4860638@2x.png'),
                ), label: '.'  ,),
              BottomNavigationBarItem(icon: ImageIcon(
                AssetImage('images/3257419 - Copy 1@2x.png'),
              ), label: '.'),
              BottomNavigationBarItem(
                  icon: ImageIcon(
                    AssetImage('images/Home-icon 1@2x.png'),
                  ), label: ''),
              BottomNavigationBarItem(
                  icon: ImageIcon(
                    AssetImage('images/Booking-Metting - Copy 1@2x.png'),
                  ), label: ''),
              BottomNavigationBarItem(
                  icon: ImageIcon(
                    AssetImage('images/User_font_awesome 2@2x.png'),
                  ), label: ''),
            ],
            unselectedItemColor: Colors.grey,
            selectedItemColor: Colors.black,
            showUnselectedLabels: true,
          ),
        ),
      );

  }
}
