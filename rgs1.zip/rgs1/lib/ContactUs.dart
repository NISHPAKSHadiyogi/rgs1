
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'Login.dart';

class ContactusScreen extends StatefulWidget {
  const ContactusScreen({Key? key}) : super(key: key);

  @override
  _ContactusScreenState createState() => _ContactusScreenState();
}

class _ContactusScreenState extends State<ContactusScreen> {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    // TextEditingController Controlleruser = TextEditingController();
    bool hidepassword = true;
    const color = const Color(0xFF563B5A);
    const color2 = const Color(0xFF162037);


    // startTimer();
    return Container(
      height: height,
      width: width,

      child: Scaffold(


        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: color,
          title: Text("Contact Us ",style:TextStyle(color: Colors.white,fontSize: 24) ,),
          centerTitle: true,
          actions: [
            IconButton(
                icon: ImageIcon(
                  AssetImage('images/Logout 1@2x.png'),
                ),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                  //code to execute when this button is pressed
                }
            ),
          ],
        ),
        body: Stack(

            children: <Widget>[
              // Map View

              // Show zoom buttons
              SafeArea(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 10.0,top: 20.0,right: 10.0),
                    child:
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        //   Text("| Income Tax                ",style:TextStyle(color: color,fontSize: 32,fontWeight: FontWeight.bold) ,),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image( height: 200,width:320,image: AssetImage('images/contactus.png'),),
                          ],
                        ),
                        SizedBox(height: 20,),

                        Container(

                          child: Card(

                         shadowColor: color,
                          elevation: 2,
                           child:
                           Container(
                             padding: EdgeInsets.only(right: 7),
                             color: color,
                             child: Container(
                               padding: EdgeInsets.only(left: 2),
                               color: Colors.white,
                               child:  Row(
                                 children: [
                                   Container(
                                     decoration: BoxDecoration(color:color,
                                       border: Border.all(width: 1.1),


                                       borderRadius: BorderRadius.circular(5.0),
                                     ),
                                     width: width/5,
                                     height: height/10,
                                     margin: const EdgeInsets.all(2.0),
                                     padding: EdgeInsets.all(13),


                                     child: Image(image: AssetImage('images/loginmail.png'),),
                                   ),
                                   SizedBox(width: 5,),
                                   Container(
                                     width: width/1.5,
                                     child: Text('hello@rgsaccountsfcdg.co.uk',
                                       style: TextStyle(color: Colors.grey,fontSize: 14),),
                                   ),
                                 ],
                               ),
                             ),
                           )
                       )
        ),
                        SizedBox(height: 20,),
                        Container(

                            child: Card(

                                shadowColor: color,
                                elevation: 2,
                                child:
                                Container(
                                  padding: EdgeInsets.only(right: 7),
                                  color: color,
                                  child: Container(
                                    padding: EdgeInsets.only(left: 2),
                                    color: Colors.white,
                                    child:  Row(
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(color:color,
                                            border: Border.all(width: 1.1),


                                            borderRadius: BorderRadius.circular(5.0),
                                          ),
                                          width: width/5,
                                          height: height/10,
                                          margin: const EdgeInsets.all(2.0),
                                          padding: EdgeInsets.all(13),


                                          child: Image(image: AssetImage('images/phone.png'),),
                                        ),
                                        SizedBox(width: 5,),
                                        Container(
                                          width: width/1.5,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text('Swesna +44 1639 4910 170',
                                                style: TextStyle(color: Colors.grey,fontSize: 14),),
                                              SizedBox(height: 5,),
                                              Text('Mobile +44 7465 816 810',
                                                style: TextStyle(color: Colors.grey,fontSize: 14),),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                )







                            )
                        ),
                        SizedBox(height: 20,),
                        Container(

                            child: Card(

                                shadowColor: color,
                                elevation: 2,
                                child:
                                Container(
                                  padding: EdgeInsets.only(right: 7),
                                  color: color,
                                  child: Container(
                                    padding: EdgeInsets.only(left: 2),
                                    color: Colors.white,
                                    child:  Row(
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(color:color,
                                            border: Border.all(width: 1.1),


                                            borderRadius: BorderRadius.circular(5.0),
                                          ),
                                          width: width/5,
                                          height: height/10,
                                          margin: const EdgeInsets.all(2.0),
                                          padding: EdgeInsets.all(13),


                                          child: Image(image: AssetImage('images/12168951@2x.png'),),
                                        ),
                                        SizedBox(width: 5,),
                                        Container(
                                          width: width/1.5,
                                          child: Text('5 Commercial Steet, Ystradgynlias, SA9 1HD 11 Angel Street, Neath, SA11 1RS',
                                            style: TextStyle(color: Colors.grey,fontSize: 14),),
                                        ),
                                      ],
                                    ),
                                  ),
                                )







                            )
                        ),


                      ],

                    ),
                  ),
                ),
              ),
            ]
        ),
        bottomNavigationBar: bottomNavigationBar,
      ),

      // Show the place input fields & button for
    );
  }
  Widget get bottomNavigationBar {
    return
      Container(
        decoration: BoxDecoration(color:Colors.red,
          border: Border.all(width: 0.5),

          borderRadius: BorderRadius.circular(200.0),
        ),
        margin: const EdgeInsets.all(10.0),
        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
        child:
        ClipRRect(

          clipBehavior: Clip.antiAliasWithSaveLayer,

          borderRadius: const BorderRadius.only(
            topRight: Radius.circular(200),
            topLeft: Radius.circular(200),
            bottomLeft: Radius.circular(200),
            bottomRight: Radius.circular(200),

          ),
          child: BottomNavigationBar(
            iconSize: 35,
            items: const [
              BottomNavigationBarItem(

                icon: ImageIcon(

                  AssetImage('images/4860638@2x.png'),
                ), label: '.'  ,),
              BottomNavigationBarItem(icon: ImageIcon(
                AssetImage('images/3257419 - Copy 1@2x.png'),
              ), label: '.'),
              BottomNavigationBarItem(
                  icon: ImageIcon(
                    AssetImage('images/Home-icon 1@2x.png'),
                  ), label: ''),
              BottomNavigationBarItem(
                  icon: ImageIcon(
                    AssetImage('images/Booking-Metting - Copy 1@2x.png'),
                  ), label: ''),
              BottomNavigationBarItem(
                  icon: ImageIcon(
                    AssetImage('images/User_font_awesome 2@2x.png'),
                  ), label: ''),
            ],
            unselectedItemColor: Colors.grey,
            selectedItemColor: Colors.black,
            showUnselectedLabels: true,
          ),
        ),
      );

  }
}
