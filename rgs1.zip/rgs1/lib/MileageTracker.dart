import 'dart:async';

import 'package:flutter/material.dart';
import 'package:rgs/Models/Person.dart';
import 'package:syncfusion_flutter_core/theme.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'Login.dart';
import 'Models/Employee.dart';

var color = const Color(0xFF563B5A);


class MileageTrackerPage extends StatefulWidget {


  @override
  _MileageTrackerPageState createState() => _MileageTrackerPageState();
}

class _MileageTrackerPageState extends State<MileageTrackerPage> {
  DateTime selectedDate = DateTime.now();
  List<Employee> employees = <Employee>[];
  late EmployeeDataSource employeeDataSource;
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }
  @override
  void initState() {
    super.initState();
    employees = getEmployeeData();
    employeeDataSource = EmployeeDataSource(employees: employees);
  }
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    // TextEditingController Controlleruser = TextEditingController();
    bool hidepassword = true;
    const color = const Color(0xFF563B5A);
    const color2 = const Color(0xFF162037);

    List<Person> _personList = [Person(id:0,name:"",email:"",phone:"")];
    // startTimer();
    return Container(
        height: height,
        width: width,

        child: Scaffold(
      appBar: AppBar(


        backgroundColor: color,
        title: Text("Mileage Tracker",style:TextStyle(color: Colors.white,fontSize: 22) ,),
        actions: [
          IconButton(
              icon: ImageIcon(
                AssetImage('images/Logout 1@2x.png'),
              ),
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                //code to execute when this button is pressed
              }
          ),
        ],
      ),
      body: SafeArea(
      child: SingleChildScrollView(
      child: Padding(
      padding: const EdgeInsets.only(left: 10.0,top: 10.0,right: 10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [ Text("| Mileage Tracker ",
                style:TextStyle(color: color,fontSize: 22,fontWeight: FontWeight.bold) ,),
        Container( child:
        GestureDetector(
          onTap: (){showDialog(
              context: context,
              builder: (_) =>
                  CustomEventDialog(title: "titls", content: "content"));},
          child: RaisedButton(
            color: color,
            textColor: Colors.white,
                  // onPressed: () => _selectDate(context),
            onPressed: () {
              // showDialog(
              //   context: context,
              //   builder: (_) =>
              //       CustomEventDialog(title: "titls", content: "content"));
              },
            child: Text('Start'),

          ),
        )
        ),
          ],),
            SizedBox(height: 10,),


            Text("Mileage Tracker  Mileage Tracker Mileage Tracker Mileage Tracker Mileage Tracker "
                "Mileage Tracker  ",
              style:TextStyle(color: Colors.grey,fontSize: 14,) ,),
            SizedBox(height: 7,),
            Text(" Search Record    ",style:TextStyle(color: Colors.grey,fontSize: 18,fontWeight: FontWeight.bold) ,),
           Card(
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [Text("${selectedDate.toLocal()}".split(' ')[0]),
            SizedBox(height: 30.0,width: 15,),

              IconButton(


                icon: ImageIcon( AssetImage('images/date.png'),),
              onPressed: () => _selectDate(context),

            ),
              Text("${selectedDate.toLocal()}".split(' ')[0]),
              SizedBox(height: 30.0,width: 25,),
              IconButton(


                icon: ImageIcon( AssetImage('images/date.png'),),
                color: color2,
                onPressed: () => _selectDate(context),

              ),

            ],
            )
           ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
            //  crossAxisAlignment: CrossAxisAlignment.center,
              children: [Container( child:
            RaisedButton(
              color: color,
              textColor: Colors.white,
              onPressed: () => _selectDate(context),
              child: Text('Go'),

            )
            ),
              SizedBox(width: 10,),
              Container( child:
              RaisedButton(

                color: color,
                textColor: Colors.white,
                onPressed: () => _selectDate(context),
                child: Row(children: [
                  ImageIcon(AssetImage('images/download.png')),
                  Text('Download'),],)

              )
              ),
            ],),

            Container(
              decoration: BoxDecoration(color:color,
                 border: Border.all(color: color
                     ,width: 0.5),
                borderRadius: BorderRadius.circular(5.0),
              ),
              child: SfDataGridTheme(
                data: SfDataGridThemeData(headerColor:  Colors.pink.shade50),
                child:SfDataGrid(
                source: employeeDataSource,
                gridLinesVisibility: GridLinesVisibility.both,
                headerGridLinesVisibility: GridLinesVisibility.both,


                columnWidthMode: ColumnWidthMode.fill,
                columns: <GridColumn>[

                  GridColumn(
                      columnName: 'id',
                      label: Container(
                          padding: EdgeInsets.symmetric(horizontal: 16.0),
                          alignment: Alignment.center,
                          child: Text(
                            'Date',
                          ))),
                  GridColumn(
                      columnName: 'name',
                      label: Container(
                          padding: EdgeInsets.symmetric(horizontal: 16.0),
                          alignment: Alignment.center,
                          child: Text('Start Time'))),
                  GridColumn(
                      columnName: 'designation',
                      label: Container(
                          padding: EdgeInsets.symmetric(horizontal: 16.0),
                          alignment: Alignment.center,
                          child: Text(
                            'End Time',

                          ))),
                  GridColumn(
                      columnName: 'salary',
                      label: Container(
                          padding: EdgeInsets.symmetric(horizontal: 16.0),
                          alignment: Alignment.center,
                          child: Text('Run Miles'))),
                ],
              ),
              ),
            ),
          ],
        ),
      ),
        ),
      ),
         // bottomNavigationBar: bottomNavigationBar,
        ),
    );

  }
  List<Employee> getEmployeeData() {
    return [
      Employee(10001, 'James', 'Project Lead', 20000),
      Employee(10002, 'Kathryn', 'Manager', 30000),
      Employee(10003, 'Lara', 'Developer', 15000),
      Employee(10004, 'Michael', 'Designer', 15000),
      Employee(10005, 'Martin', 'Developer', 15000),
      Employee(10006, 'Newberry', 'Developer', 15000),
      Employee(10007, 'Balnc', 'Developer', 15000),
      Employee(10008, 'Perry', 'Developer', 15000),
      Employee(10009, 'Gable', 'Developer', 15000),
      Employee(10010, 'Grimes', 'Developer', 15000),
      Employee(10011, 'James', 'Project Lead', 20000),
      Employee(10012, 'Kathryn', 'Manager', 30000),
      Employee(10013, 'Lara', 'Developer', 15000),
      Employee(10014, 'Michael', 'Designer', 15000),
    ];
  }
  Widget get bottomNavigationBar {
    return
      Container(
        decoration: BoxDecoration(color:Colors.red,
          border: Border.all(width: 0.5),

          borderRadius: BorderRadius.circular(200.0),
        ),
        margin: const EdgeInsets.all(10.0),
        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
        child:
        ClipRRect(

          clipBehavior: Clip.antiAliasWithSaveLayer,

          borderRadius: const BorderRadius.only(
            topRight: Radius.circular(200),
            topLeft: Radius.circular(200),
            bottomLeft: Radius.circular(200),
            bottomRight: Radius.circular(200),

          ),
          child: BottomNavigationBar(
            iconSize: 35,
            items: const [
              BottomNavigationBarItem(

                icon: ImageIcon(

                  AssetImage('images/4860638@2x.png'),
                ), label: '.'  ,),
              BottomNavigationBarItem(icon: ImageIcon(
                AssetImage('images/3257419 - Copy 1@2x.png'),
              ), label: '.'),
              BottomNavigationBarItem(
                  icon: ImageIcon(
                    AssetImage('images/Home-icon 1@2x.png'),
                  ), label: ''),
              BottomNavigationBarItem(
                  icon: ImageIcon(
                    AssetImage('images/Booking-Metting - Copy 1@2x.png'),
                  ), label: ''),
              BottomNavigationBarItem(
                  icon: ImageIcon(
                    AssetImage('images/User_font_awesome 2@2x.png'),
                  ), label: ''),
            ],
            unselectedItemColor: Colors.grey,
            selectedItemColor: Colors.black,
            showUnselectedLabels: true,
          ),
        ),
      );

  }
}

class CustomEventDialog extends StatefulWidget {
  final title;
  final  content;
  CustomEventDialog({this.title, this.content});

  @override
  CustomEventDialogState createState() => new CustomEventDialogState();
}

class CustomEventDialogState extends State<CustomEventDialog> {

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Dialog(
        backgroundColor: Colors.transparent,

        child: Container(
          width: size.width*0.7,
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
            color: Colors.white,
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: Wrap(
              children: <Widget>[

                Center(
                  child: Container(
                    height: size.height*.27,
                    width: size.width*.75,

                    child: Column(

                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 3),

                          height: 50,
                          width: size.width*.85,
                          //alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: Color(0xFF563B5A),
                            borderRadius: BorderRadius.all(
                                Radius.circular(0)
                            ),
                            border: Border.all(
                              color: Color(0xFF563B5A),
                            ),
                          ),
                          child: Center(
                            child: Text("Confirmation",
                              style: TextStyle(color:Colors.white,fontSize: 20,fontWeight: FontWeight.w700),),
                          ),

                        ),
                        SizedBox(height: 15,),
                        Center(
                          child: Text('Do you want to start your journey',
                            style: TextStyle(color: Colors.grey,
                                fontSize: 15),),
                        ),
                        SizedBox(height: 7,),
                        // Center(child: Text('Are you sure?',
                        //   style: TextStyle(color: Colors.grey,fontSize: 15),)),
                        SizedBox(height: 25,),



                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                margin: EdgeInsets.only(top: 5),

                                height: 40,
                                width: size.width*.25,
                                //alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color:Color(0xFF563B5A),
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(5)
                                  ),
                                  border: Border.all(
                                    color: Color(0xFF563B5A),
                                  ),
                                ),
                                child: Center(
                                  child: Text("Yes",
                                    style: TextStyle(color:Colors.white,fontSize: 15),),
                                ),

                              ),
                            ),
                            SizedBox(
                              width: 30,
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 5),

                              height: 40,
                              width: size.width*.25,
                              //alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.all(
                                    Radius.circular(5)
                                ),
                                border: Border.all(
                                  color: Color(0xFF563B5A),
                                ),
                              ),
                              child: Center(
                                child: Text("No",
                                  style: TextStyle(color:Color(0xFF563B5A),fontSize: 15),),
                              ),

                            ),
                          ],
                        ),







                        //Text(_selectedGender == 'male' ? 'Hello gentlement!' : 'Hi lady!')
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}