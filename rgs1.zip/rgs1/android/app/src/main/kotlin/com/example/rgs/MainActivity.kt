package com.example.rgs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
